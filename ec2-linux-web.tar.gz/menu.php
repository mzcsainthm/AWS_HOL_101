<div id="header"><a href="/"><img src="https://workshop.mzcloud.xyz/AWS-101-v2/download/MEGAZONECLOUD_LOGO.png" width="600" height="154" /></a></div>

<div id='menu'>
<ul>
  <li><a href="load.php">Load Test</a></li>
</ul>
</div>
