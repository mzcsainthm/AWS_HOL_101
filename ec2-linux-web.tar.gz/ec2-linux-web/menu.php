<div id="header"><a href="/"><img src="./MEGAZONE_CLOUD_LOGO.jpeg" width="600" height="154" /></a></div>

<div id='menu'>
<ul>
  <li><a href="load.php">Load Test</a></li>
</ul>
</div>
