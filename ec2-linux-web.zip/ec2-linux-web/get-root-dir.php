<?php
  # This code view a root directory path
  echo "</br><p>Web Root Path : <b>"; 
  echo dirname(__FILE__);
  echo "</b></br></p>";
?>
